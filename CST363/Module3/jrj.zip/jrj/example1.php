<html>
   <head>
      <title>Online PHP Script Execution</title>      
   </head>
   
   <body>
      
      <?php
         echo "<h1>Hello World, PHP!</h1>";
      ?>
   
   </body>
</html>